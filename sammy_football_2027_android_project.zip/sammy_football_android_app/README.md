# Sammy Football 2027 Android App Project

This is an Android Studio project wrapping the Sammy Football 2027 HTML game in a full-screen Android WebView. The game uses Three.js from jsDelivr, so an internet connection is needed for the 3D game to load.

## Easiest build route using GitHub
1. Sign in to GitHub and create a new repository named `sammy-football-2027-android`.
2. Upload the contents of this ZIP (upload the files and folders inside, not the ZIP itself). Make sure `.github/workflows/build-apk.yml` is included. If GitHub hides `.github`, use the repository's web upload or create that workflow in the GitHub Actions editor.
3. Open the repository's **Actions** tab.
4. Choose **Build Sammy Football APK** and press **Run workflow** (or wait for the automatic build after pushing files to `main`).
5. When the workflow finishes with a green tick, open that run and download the artifact named `Sammy-Football-2027-APK`.
6. Extract the downloaded artifact ZIP and tap `app-debug.apk` on your Android phone to install it. Android may ask you to allow installs from that source.

## Build with Android Studio
Open this folder in Android Studio and build `app` > `assembleDebug`. The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

This is a debug/test APK, not a Play Store release. The app requests internet access because the 3D engine is loaded from a CDN. Do not remove the `.github` workflow folder if you want GitHub to build the APK for you.
